#include <iostream>
using namespace std;

struct Applicant {
    int id;
    float height, weight, eyesight;
    string status;
    Applicant* next;
    Applicant* prev;
};

// Enqueue (add at rear)
void enqueue(Applicant* &front, Applicant* &rear, int id) {
    Applicant* temp = new Applicant{id, 0, 0, 0, "Waiting", NULL, NULL};

    if (rear == NULL) {
        front = rear = temp;
    } else {
        rear->next = temp;
        temp->prev = rear;
        rear = temp;
    }
}

// Dequeue (remove from front)
void dequeue(Applicant* &front, Applicant* &rear) {
    if (front == NULL) {
        cout << "Queue is empty\n";
        return;
    }

    Applicant* temp = front;
    cout << "Applicant " << temp->id << " completed test\n";

    front = front->next;

    if (front != NULL)
        front->prev = NULL;
    else
        rear = NULL;

    delete temp;
}

// Remove 2nd person
void removeSecond(Applicant* &front) {
    if (front == NULL || front->next == NULL) {
        cout << "Not enough applicants\n";
        return;
    }

    Applicant* temp = front->next;
    cout << "Applicant " << temp->id << " left due to urgency\n";

    front->next = temp->next;

    if (temp->next != NULL)
        temp->next->prev = front;

    delete temp;
}

// Display queue
void display(Applicant* front) {
    cout << "Queue: ";
    while (front != NULL) {
        cout << front->id << " ";
        front = front->next;
    }
    cout << endl;
}

int main() {
    Applicant *front = NULL, *rear = NULL;

    // Add 7 applicants
    for (int i = 1; i <= 7; i++)
        enqueue(front, rear, i);

    display(front);

    // Remove 2nd person
    removeSecond(front);
    display(front);

    // First person gives test
    dequeue(front, rear);
    display(front);

    return 0;
}
