#include <iostream>
#include <queue>
#include <stack>
using namespace std;

queue<int> road;
stack<int> garage;

// Truck arrives on road
void On_road(int id) {
    road.push(id);
    cout << "Truck " << id << " on road\n";
}

// Move truck into garage
void Enter_garage() {
    if (road.empty()) {
        cout << "No trucks on road\n";
        return;
    }

    int id = road.front();
    road.pop();
    garage.push(id);

    cout << "Truck " << id << " entered garage\n";
}

// Exit garage
void Exit_garage(int id) {
    if (garage.empty()) {
        cout << "Garage empty\n";
        return;
    }

    if (garage.top() == id) {
        garage.pop();
        cout << "Truck " << id << " exited garage\n";
    } else {
        cout << "Truck is not near garage door\n";
    }
}

// Display
void Show_trucks() {
    queue<int> r = road;
    stack<int> g = garage;

    cout << "Road: ";
    while (!r.empty()) {
        cout << r.front() << " ";
        r.pop();
    }

    cout << "\nGarage: ";
    while (!g.empty()) {
        cout << g.top() << " ";
        g.pop();
    }

    cout << endl;
}

int main() {
    On_road(101);
    On_road(102);
    On_road(103);

    Enter_garage();
    Enter_garage();

    Show_trucks();

    Exit_garage(101); // wrong
    Exit_garage(102); // correct

    Show_trucks();

    return 0;
}
